import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import OpenAI from 'openai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = Number(process.env.PORT || 3000);
const MODEL = process.env.OPENAI_MODEL || 'gpt-6-luna';
const VECTOR_STORE_ID = process.env.OPENAI_VECTOR_STORE_ID || '';
const client = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

app.use(express.json({ limit: '1mb' }));
app.use(express.static(__dirname));

const SYSTEM = `Eres el asistente de LR CONNECT, una aplicación independiente para clientes y socios.
Responde siempre en español claro y natural.
REGLAS IMPORTANTES:
- Cuando la pregunta sea sobre productos, características, referencias, formatos, precios, perfumes, uso o documentación LR, usa la biblioteca proporcionada mediante file_search como fuente principal.
- No inventes propiedades, precios, referencias, descuentos, resultados ni disponibilidad.
- Si la documentación no permite responder, dilo claramente y pide consultar una fuente LR vigente.
- No diagnostiques enfermedades ni presentes complementos/cosméticos como tratamientos médicos.
- Distingue entre información que aparece en los documentos y recomendaciones generales.
- Si el usuario pide un guion de marketing, crea un texto atractivo pero sin afirmaciones médicas o económicas no respaldadas.
- La app no es oficial de LR Health & Beauty salvo que el propietario obtenga autorización expresa.`;

function requireAI(res) {
  if (!client) {
    res.status(503).json({ ok: false, error: 'IA no configurada. Añade OPENAI_API_KEY en el servidor.' });
    return false;
  }
  if (!VECTOR_STORE_ID) {
    res.status(503).json({ ok: false, error: 'Biblioteca IA no configurada. Ejecuta npm run setup:knowledge.' });
    return false;
  }
  return true;
}

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, ai: Boolean(client), knowledgeBase: Boolean(VECTOR_STORE_ID), model: MODEL });
});

app.post('/api/chat', async (req, res) => {
  if (!requireAI(res)) return;
  const message = String(req.body?.message || '').trim();
  if (!message) return res.status(400).json({ ok: false, error: 'Mensaje vacío.' });
  try {
    const response = await client.responses.create({
      model: MODEL,
      instructions: SYSTEM,
      tools: [{ type: 'file_search', vector_store_ids: [VECTOR_STORE_ID], max_num_results: 8 }],
      input: message
    });
    res.json({ ok: true, text: response.output_text || 'No pude generar una respuesta.' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ ok: false, error: error?.message || 'Error consultando la IA.' });
  }
});

app.post('/api/content', async (req, res) => {
  if (!requireAI(res)) return;
  const product = String(req.body?.product || '').trim();
  const platform = String(req.body?.platform || 'TikTok').trim();
  if (!product) return res.status(400).json({ ok: false, error: 'Producto no indicado.' });
  const prompt = `Crea un guion para ${platform} sobre el producto "${product}".\n\nEstructura obligatoria:\n1) HOOK de 1 frase.\n2) ESCENAS: 4 escenas cortas, cada una con VISUAL, NARRACIÓN y TEXTO EN PANTALLA.\n3) CTA final.\n4) NOTA DE FUENTE: indica que la información de producto debe verificarse en la documentación LR vigente.\n\nUsa file_search para obtener únicamente los datos que estén respaldados por la biblioteca. No inventes beneficios médicos, precios ni resultados económicos.`;
  try {
    const response = await client.responses.create({
      model: MODEL,
      instructions: SYSTEM,
      tools: [{ type: 'file_search', vector_store_ids: [VECTOR_STORE_ID], max_num_results: 8 }],
      input: prompt
    });
    res.json({ ok: true, text: response.output_text || 'No pude generar el guion.' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ ok: false, error: error?.message || 'Error generando contenido.' });
  }
});

app.get(/.*/, (_req, res) => res.sendFile(path.join(__dirname, 'index.html')));

app.listen(PORT, () => {
  console.log(`LR CONNECT V9 funcionando en http://localhost:${PORT}`);
  console.log(`IA: ${client ? 'configurada' : 'pendiente'} | Biblioteca: ${VECTOR_STORE_ID ? 'configurada' : 'pendiente'} | Modelo: ${MODEL}`);
});

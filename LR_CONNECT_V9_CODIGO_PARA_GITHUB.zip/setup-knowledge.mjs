import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import OpenAI from 'openai';

if (!process.env.OPENAI_API_KEY) {
  console.error('Falta OPENAI_API_KEY. Crea .env a partir de .env.example.');
  process.exit(1);
}

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const docsDir = path.join(process.cwd(), 'docs');
const docs = fs.readdirSync(docsDir).filter(name => name.toLowerCase().endsWith('.pdf')).sort();
if (!docs.length) {
  console.error('No hay PDFs en docs/.');
  process.exit(1);
}

let vectorStoreId = process.env.OPENAI_VECTOR_STORE_ID;
if (!vectorStoreId) {
  const store = await openai.vectorStores.create({ name: 'LR CONNECT - Biblioteca' });
  vectorStoreId = store.id;
  console.log(`Vector store creado: ${vectorStoreId}`);
  console.log('Guarda este ID en .env como OPENAI_VECTOR_STORE_ID=...');
}

for (const filename of docs) {
  const full = path.join(docsDir, filename);
  console.log(`Subiendo: ${filename}`);
  const file = await openai.files.create({
    file: fs.createReadStream(full),
    purpose: 'user_data'
  });
  await openai.vectorStores.files.create(vectorStoreId, { file_id: file.id });
  console.log(`  OK -> ${file.id}`);
}

console.log('\nLISTO. Biblioteca conectada.');
console.log(`OPENAI_VECTOR_STORE_ID=${vectorStoreId}`);
console.log('Si el archivo .env no contiene este ID, añádelo antes de arrancar el servidor.');
